package com.exam.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.model.exam.Category;
import com.exam.model.exam.Questions;
import com.exam.model.exam.Quiz;
import com.exam.service.impl.CategoryServiceImpl;
import com.exam.service.impl.QuestionServiceImpl;
import com.exam.service.impl.QuizServiceImpl;

@RestController
@CrossOrigin("http://localhost:3000")
public class ExamController {

	@Autowired
	private CategoryServiceImpl categoryServiceImpl;
	@Autowired
	private QuizServiceImpl quizServiceImpl;
	@Autowired
	private QuestionServiceImpl questionServiceImpl;

	// For Category RestAPI

	@PostMapping("/category/create")
	public ResponseEntity<Category> addCategory(@RequestBody Category category) {
		return new ResponseEntity<Category>(categoryServiceImpl.addCategory(category), HttpStatus.CREATED);
	}

	@GetMapping("/category/getCategory/{cID}")
	public ResponseEntity<Category> getCategory(@PathVariable("cID") int cID) {
		return new ResponseEntity<Category>(categoryServiceImpl.getCategory(cID), HttpStatus.OK);
	}

	@GetMapping("/category/getAllCategories")
	public ResponseEntity<List<Category>> getAllCategory() {
		return new ResponseEntity<List<Category>>(categoryServiceImpl.getCategories(), HttpStatus.OK);
	}

	@PutMapping("/category/updateCategory/{cID}")
	public ResponseEntity<Category> updateCategory(@PathVariable("cID") int cID, @RequestBody Category category) {
		return new ResponseEntity<Category>(categoryServiceImpl.updateCategory(cID, category), HttpStatus.OK);
	}

	@DeleteMapping("/category/deleteCategory/{cID}")
	public ResponseEntity<?> deleteCategory(@PathVariable("cID") int cID) {
		categoryServiceImpl.deleteCategory(cID);

		return new ResponseEntity<String>("Category Deleted", HttpStatus.OK);
	}

	// For Quiz RestAPI

	@PostMapping("/quiz/create")
	public ResponseEntity<Quiz> addQuiz(@RequestBody Quiz quiz) {
		return new ResponseEntity<Quiz>(quizServiceImpl.addQuiz(quiz), HttpStatus.CREATED);
	}

	@GetMapping("quiz/getquiz/{qID}")
	public ResponseEntity<Quiz> getQuiz(@PathVariable("qID") int qID) {
		return new ResponseEntity<Quiz>(quizServiceImpl.getQuizById(qID), HttpStatus.OK);
	}

	@GetMapping("quiz/getAllCategories")
	public ResponseEntity<List<Quiz>> getAllQuiz() {
		return new ResponseEntity<List<Quiz>>(quizServiceImpl.getAllQuizs(), HttpStatus.OK);
	}

	@PutMapping("quiz/updateCategory/{qid}")
	public ResponseEntity<Quiz> updatequiz(@PathVariable("qid") int qid, @RequestBody Quiz quiz) {
		return new ResponseEntity<Quiz>(quizServiceImpl.updateQuiz(qid, quiz), HttpStatus.OK);
	}

	@DeleteMapping("/quiz/quizDelete/{qID}")
	public ResponseEntity<?> deleteQuiz(@PathVariable("qID") int qID) {
		quizServiceImpl.deleteQuiz(qID);

		return new ResponseEntity<String>("Quiz Deleted", HttpStatus.OK);
	}

	// For Question RestAPI

	@PostMapping("/question/create")
	public ResponseEntity<Questions> addQuestion(@RequestBody Questions questions) {
		return new ResponseEntity<Questions>(questionServiceImpl.addQuestions(questions), HttpStatus.CREATED);
	}

	@GetMapping("question/getQuestion/{qID}")
	public ResponseEntity<Questions> getquestion(@PathVariable("qID") int qID) {
		return new ResponseEntity<Questions>(questionServiceImpl.getQuestions(qID), HttpStatus.OK);
	}

	@GetMapping("question/getAllQuestion")
	public ResponseEntity<List<Questions>> getAllQuestions() {
		return new ResponseEntity<List<Questions>>(questionServiceImpl.getAllQuestions(), HttpStatus.OK);
	}

	@PutMapping("question/updateQuestion/{qID}")
	public ResponseEntity<Questions> updateQuestion(@PathVariable("qID") int qID, @RequestBody Questions questions) {
		return new ResponseEntity<Questions>(questionServiceImpl.updateQuestions(qID, questions), HttpStatus.OK);
	}

	@DeleteMapping("question/deleteQuestion/{qID}")
	public ResponseEntity<?> deleteQuestion(@PathVariable("qID") int qID) {
		questionServiceImpl.deleteQuestion(qID);

		return new ResponseEntity<String>("Question Deleted", HttpStatus.OK);
	}

	// Get All Question of Quiz by Quiz ID
	@GetMapping("question/getQuestionofquiz/{qid}")
	public ResponseEntity<List<Questions>> getQuestionOfQuiz(@PathVariable("qid") int qid) {
		Quiz quiz = this.quizServiceImpl.getQuizById(qid);
		Set<Questions> questions = quiz.getQuestions();
		List<Questions> list = new ArrayList<>(questions);
		if (list.size() > Integer.parseInt(quiz.getNumberofQuestions())) {
			list = list.subList(0, Integer.parseInt(quiz.getNumberofQuestions() + 1));
		}
		Collections.shuffle(list);
		return new ResponseEntity<List<Questions>>(list, HttpStatus.OK);
	}
}
