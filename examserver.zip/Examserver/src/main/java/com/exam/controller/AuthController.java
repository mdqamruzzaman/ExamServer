package com.exam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exam.model.AuthResponse;
import com.exam.model.UserModel;
import com.exam.model.UserToken;
import com.exam.service.impl.UserAuthServiceImpl;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@CrossOrigin("http://localhost:3000")
@RequestMapping("/user")
public class AuthController {

	@Autowired
	private UserAuthServiceImpl userServiceImpl;

	@PostMapping("/login")
	public ResponseEntity<UserToken> login(@RequestBody UserModel user) {
		log.info("Inside Login : ");
		return new ResponseEntity<UserToken>(userServiceImpl.login(user), HttpStatus.OK);
	}

	@GetMapping("/validate")
	public ResponseEntity<AuthResponse> getValidity(@RequestHeader("Authorization") String token) {
		log.info("Inside Token Validation... ");
		return new ResponseEntity<AuthResponse>(userServiceImpl.getValidity(token), HttpStatus.OK);
	}

}
