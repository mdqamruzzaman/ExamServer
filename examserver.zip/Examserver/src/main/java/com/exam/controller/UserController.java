package com.exam.controller;

import java.security.Principal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exam.model.ContactUs;
import com.exam.model.Role;
import com.exam.model.UserEntity;
import com.exam.model.UserRole;
import com.exam.service.UserService;
import com.exam.service.impl.ContactUsServiceImpl;

@RestController
@RequestMapping("/user")
@CrossOrigin("http://localhost:3000")
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private ContactUsServiceImpl contactUsServiceImpl;

	// creating user
	@PostMapping("/create")
	public ResponseEntity<UserEntity> createUser(@RequestBody UserEntity userEntity) {

		Set<UserRole> roles = new HashSet<>();

		// Role define
		Role role = new Role();
		role.setRoleId(45);
		role.setRoleName("NORMAL");

		// UserRole define
		UserRole userRole = new UserRole();
		userRole.setUserEntity(userEntity);
		userRole.setRole(role);

		// add userRole into role
		roles.add(userRole);

		return new ResponseEntity<UserEntity>(userService.createUser(userEntity, roles), HttpStatus.CREATED);
	}

	// Get User By Username
	@GetMapping("get/{username}")
	public ResponseEntity<UserEntity> getUser(@PathVariable("username") String username) {
		return new ResponseEntity<UserEntity>(userService.getUser(username), HttpStatus.OK);
	}

	// Get User By ID
	@GetMapping("getuserbyid/{id}")
	public ResponseEntity<UserEntity> getUserById(@PathVariable("id") int id) {
		return new ResponseEntity<UserEntity>(userService.getUserByID(id), HttpStatus.OK);
	}

	// Get All User
	@GetMapping("/getAll")
	public ResponseEntity<List<UserEntity>> getAllUser() {
		return new ResponseEntity<List<UserEntity>>(userService.getAllUser(), HttpStatus.OK);
	}

	// Delete User By UserID
	@DeleteMapping("delete/{userId}")
	public ResponseEntity<?> deleteUser(@PathVariable("userId") int userId) {
		userService.deleteUser(userId);
		System.out.println("User Deleted");
		return new ResponseEntity<String>("User Deleted", HttpStatus.OK);
	}

	// Update User by UserId
	@PutMapping("update/{userId}")
	public ResponseEntity<UserEntity> updateUser(@PathVariable("userId") int userId,
			@RequestBody UserEntity userEntity) {
		return new ResponseEntity<UserEntity>(userService.updateUser(userId, userEntity), HttpStatus.OK);
	}

	// Current User
	@GetMapping("/current_user")
	public ResponseEntity<UserEntity> getCurrentUser(Principal principal) {
		return new ResponseEntity<UserEntity>(userService.getCurrentUser(principal.getName()), HttpStatus.OK);
	}

	@PostMapping("/contactUs/create")
	public ResponseEntity<ContactUs> addContactUs(@RequestBody ContactUs contactUs) {
		return new ResponseEntity<ContactUs>(contactUsServiceImpl.addContactUs(contactUs), HttpStatus.CREATED);
	}
}
