package com.exam.exception;

public class CategoryDetailsNotFound extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public CategoryDetailsNotFound(String message) {
		super(message);
	}

}
