package com.exam.exception;

public class UserDetailsNotFound extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public UserDetailsNotFound(String message) {
		super(message);
	}

	
}
