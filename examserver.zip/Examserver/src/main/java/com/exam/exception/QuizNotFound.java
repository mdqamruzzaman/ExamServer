package com.exam.exception;

public class QuizNotFound extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public QuizNotFound(String message) {
		super(message);
	}

	
}
