package com.exam.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.exception.QuizNotFound;
import com.exam.model.exam.Quiz;
import com.exam.repo.QuizRepository;
import com.exam.service.QuizService;

@Service
public class QuizServiceImpl implements QuizService {

	@Autowired
	private QuizRepository quizRepository;

	@Override
	public Quiz addQuiz(Quiz quiz) {
		return quizRepository.save(quiz);
	}

	@Override
	public Quiz updateQuiz(int qid, Quiz quiz) {
		Optional<Quiz> getQuizOptional = quizRepository.findById(qid);
		if (getQuizOptional.isPresent()) {
			Quiz quiz2 = new Quiz();

			quiz2.setQID(qid);
			quiz2.setTitle(quiz.getTitle());
			quiz2.setDescription(quiz.getDescription());
			quiz2.setActive(true);
			quiz2.setMaxMarks(quiz.getMaxMarks());
			quiz2.setNumberofQuestions(quiz.getNumberofQuestions());
			quiz2.setCategory(quiz.getCategory());
			quiz2.setQuestions(quiz.getQuestions());

			return quizRepository.save(quiz2);
		}else {
			throw new QuizNotFound("Quiz not Found");
		}
	}

	@Override
	public Quiz getQuizById(int qId) {
		Optional<Quiz> getquiz = quizRepository.findById(qId);
		if (getquiz.isPresent()) {
			return getquiz.get();
		} else {
			throw new QuizNotFound("Quiz not found");
		}
	}

	@Override
	public List<Quiz> getAllQuizs() {

		return quizRepository.findAll();
	}

	@Override
	public void deleteQuiz(int qID) {
		System.out.println("Delete method start");
		Optional<Quiz> getQuiz = quizRepository.findById(qID);
		if (getQuiz.isPresent()) {
			quizRepository.deleteById(qID);
		} else {
			throw new QuizNotFound("Quiz not found");
		}

	}

}