package com.exam.service;

import java.util.List;

import com.exam.model.exam.Questions;

public interface QuestionService {

	public Questions addQuestions(Questions questions);

	public Questions getQuestions(int quesID);

	public List<Questions> getAllQuestions();

	public Questions updateQuestions(int qid, Questions questions);

	public void deleteQuestion(int QuesID);

}
