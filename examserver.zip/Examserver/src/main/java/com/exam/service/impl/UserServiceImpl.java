package com.exam.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.exception.UserAlreadyPresent;
import com.exam.exception.UserDetailsNotFound;
import com.exam.model.UserEntity;
import com.exam.model.UserRole;
import com.exam.repo.RoleRepository;
import com.exam.repo.UserRepository;
import com.exam.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RoleRepository roleRepository;

	// createUser
	@Override
	public UserEntity createUser(UserEntity userEntity, Set<UserRole> userRoles) {

		UserEntity local = this.userRepository.findByUsername(userEntity.getUsername());
		if (local != null) {
			System.out.println("User is already there !!");
			throw new UserAlreadyPresent("User already present !!");
		} else {
			// here user created
			for (UserRole ur : userRoles) {
				roleRepository.save(ur.getRole());
			}
			userEntity.getUserRoles().addAll(userRoles);
			local = this.userRepository.save(userEntity);
		}
		return local;
	}

	// getting user by username
	@Override
	public UserEntity getUser(String username) {
		UserEntity userDetails = userRepository.findByUsername(username);
		if (userDetails == null) {
			System.out.println("User is not available");
			throw new UserDetailsNotFound("User Details not found ");
		} else {
			// here get user
			return userDetails;
		}
	}

	public void deleteUser(int userId) {
		Optional<UserEntity> userDetails = userRepository.findById(userId);
		if (userDetails.isPresent()) {
			// User is deleted here by ID
			userRepository.deleteById(userId);
		} else {
			throw new UserDetailsNotFound("User Details not found so we can not details");
		}

	}

	public UserEntity updateUser(int userId, UserEntity userEntity) {
		Optional<UserEntity> userDetails = userRepository.findById(userId);
		if (userDetails.isPresent()) {
			UserEntity users = new UserEntity();

			// updating the details of the user
			users.setId(userId);
			users.setUsername(userEntity.getUsername());
			users.setPassword(userEntity.getPassword());
			users.setFirstname(userEntity.getFirstname());
			users.setLastname(userEntity.getLastname());
			users.setEmail(userEntity.getEmail());
			users.setPhone(userEntity.getPhone());
			users.setEnabled(true);
			users.setProfile(userEntity.getProfile());
			return userRepository.save(users);
		} else {
			System.out.println("User is not available so we can not update");
			throw new UserDetailsNotFound("User is not available so we can not update");
		}
	}

	@Override
	public List<UserEntity> getAllUser() {
		return userRepository.findAll();
	}

	@Override
	public UserEntity getCurrentUser(String username) {

		UserEntity userDetails = userRepository.findByUsername(username);
		if (userDetails == null) {
			System.out.println("User is not available");
			throw new UserDetailsNotFound("User Details not found ");
		} else {
			// here get user
			return userDetails;
		}
	}

	@Override
	public UserEntity getUserByID(int id) {
		Optional<UserEntity> getUserDetails = userRepository.findById(id);
		if (getUserDetails.isPresent()) {
			return getUserDetails.get();
		} else {
			throw new UserDetailsNotFound("User Details not found");
		}
	}

}
