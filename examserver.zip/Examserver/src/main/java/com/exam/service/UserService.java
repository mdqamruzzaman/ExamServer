package com.exam.service;

import java.util.List;
import java.util.Set;

import com.exam.model.UserEntity;
import com.exam.model.UserRole;

public interface UserService {

	// creating user
	public UserEntity createUser(UserEntity userEntity, Set<UserRole> userRoles);

	// get user by username
	public UserEntity getUser(String username);

	// get user by username
	public UserEntity getUserByID(int id);

	// delete user by username
	public void deleteUser(int userId);

	// update user by username
	public UserEntity updateUser(int userId, UserEntity userEntity);

	// get all user
	public List<UserEntity> getAllUser();

	// get the current user
	public UserEntity getCurrentUser(String username);
}
