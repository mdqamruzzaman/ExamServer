package com.exam.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.model.ContactUs;
import com.exam.repo.ContactUsRepo;
import com.exam.service.ContactUsService;

@Service
public class ContactUsServiceImpl implements ContactUsService{

	@Autowired
	private ContactUsRepo contactUsRepo;
	@Override
	public ContactUs addContactUs(ContactUs contactUs) {
		return contactUsRepo.save(contactUs);
	}

	
}
