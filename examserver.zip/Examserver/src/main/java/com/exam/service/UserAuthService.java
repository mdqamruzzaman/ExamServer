package com.exam.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.exam.model.AuthResponse;
import com.exam.model.UserModel;
import com.exam.model.UserToken;

public interface UserAuthService extends UserDetailsService {
	public UserToken login(UserModel userModel);

	public AuthResponse getValidity(String token);
}
