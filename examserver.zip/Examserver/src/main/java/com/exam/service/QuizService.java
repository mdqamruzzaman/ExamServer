package com.exam.service;

import java.util.List;

import com.exam.model.exam.Quiz;

public interface QuizService {

	public Quiz addQuiz(Quiz quiz);

	public Quiz updateQuiz(int qid, Quiz quiz);

	public Quiz getQuizById(int qId);

	public List<Quiz> getAllQuizs();

	public void deleteQuiz(int qID);
}
