package com.exam.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.exception.QuestionNotFound;
import com.exam.model.exam.Questions;
import com.exam.repo.QuestionRepository;
import com.exam.service.QuestionService;

@Service
public class QuestionServiceImpl implements QuestionService {

	@Autowired
	private QuestionRepository questionRepository;

	@Override
	public Questions addQuestions(Questions questions) {
		return questionRepository.save(questions);
	}

	@Override
	public Questions getQuestions(int quesID) {
		Optional<Questions> getQuestions = questionRepository.findById(quesID);
		if (getQuestions.isPresent()) {
			return getQuestions.get();
		} else {
			throw new QuestionNotFound("Question Not Found");
		}

	}

	@Override
	public List<Questions> getAllQuestions() {
		return questionRepository.findAll();
	}

	@Override
	public Questions updateQuestions(int qID, Questions questions) {
		Optional<Questions> getQuestions = questionRepository.findById(qID);
		if (getQuestions.isPresent()) {
			Questions que = new Questions();
			que.setQuesID(qID);
			que.setOption1(questions.getOption1());
			que.setOption2(questions.getOption2());
			que.setOption3(questions.getOption3());
			que.setOption4(questions.getOption4());
			que.setAnswer(questions.getAnswer());
			que.setContent(questions.getContent());
			que.setImage(questions.getImage());

			return questionRepository.save(que);
		} else {
			throw new QuestionNotFound("Question not found");
		}
	}

	@Override
	public void deleteQuestion(int QuesID) {
		Optional<Questions> getQuestions = questionRepository.findById(QuesID);
		if (getQuestions.isPresent()) {
			questionRepository.deleteById(QuesID);
		} else {
			throw new QuestionNotFound("Question Not Found");
		}
	}

}
