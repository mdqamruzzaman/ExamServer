package com.exam.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.exception.CategoryDetailsNotFound;
import com.exam.model.exam.Category;
import com.exam.repo.CategoryRepository;
import com.exam.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryRepository categoryRepository;

	@Override
	public Category addCategory(Category category) {
		return categoryRepository.save(category);
	}

	@Override
	public Category updateCategory(int cID, Category category) {
		Optional<Category> getCategoryOptional = categoryRepository.findById(cID);
		if (getCategoryOptional.isPresent()) {
			Category category2 = new Category();
			category2.setCID(cID);
			category2.setTitle(category.getTitle());
			category2.setDescription(category.getDescription());
			category2.setQuizzeSet(category.getQuizzeSet());
			
			return categoryRepository.save(category2);
		} else {
			throw new CategoryDetailsNotFound("Category Details Not Found");
		}
	}

	@Override
	public List<Category> getCategories() {

		return categoryRepository.findAll();
	}

	@Override
	public Category getCategory(int cID) {
		Optional<Category> getCategory = categoryRepository.findById(cID);
		if (getCategory.isPresent()) {
			return getCategory.get();
		} else {
			throw new CategoryDetailsNotFound("CategoryDetailsNotFound");
		}

	}

	@Override
	public void deleteCategory(int cID) {
		Optional<Category> getCategory = categoryRepository.findById(cID);
		if (getCategory.isPresent()) {
			categoryRepository.deleteById(cID);
		} else {
			throw new CategoryDetailsNotFound("CategoryDetailsNotFound");
		}

	}

}
