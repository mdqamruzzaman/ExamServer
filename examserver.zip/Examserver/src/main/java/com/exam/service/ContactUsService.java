package com.exam.service;

import com.exam.model.ContactUs;

public interface ContactUsService {

	public ContactUs addContactUs(ContactUs contactUs);
}
