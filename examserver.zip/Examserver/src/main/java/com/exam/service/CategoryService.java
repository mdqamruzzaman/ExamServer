package com.exam.service;

import java.util.List;

import com.exam.model.exam.Category;

public interface CategoryService {

	public Category addCategory(Category category);

	public Category updateCategory(int cID, Category category);

	public List<Category> getCategories();

	public Category getCategory(int cID);

	public void deleteCategory(int cID);
}
