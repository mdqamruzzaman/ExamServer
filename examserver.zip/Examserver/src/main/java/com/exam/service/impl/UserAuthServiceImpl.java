package com.exam.service.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.exam.exception.UnauthorizedException;
import com.exam.jwt.JwtUtil;
import com.exam.model.AuthResponse;
import com.exam.model.UserEntity;
import com.exam.model.UserToken;
import com.exam.model.UserModel;
import com.exam.repo.UserRepository;
import com.exam.service.UserAuthService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserAuthServiceImpl implements UserAuthService {
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private JwtUtil jwtUtil;

	@Override
	public UserDetails loadUserByUsername(String userName) {
		// all actions to check the correctness of the userID
		log.info("Inside loadbyusername");
		UserEntity user = userRepository.findByUsername(userName);
		return new User(user.getUsername(), user.getPassword(), new ArrayList<>());
	}

	// authenticates the user
	@Override
	public UserToken login(UserModel userModel) {

		final UserDetails userdetails = loadUserByUsername(userModel.getUsername());

		UserToken userToken = new UserToken();

		// if the password matches
		if (userdetails.getPassword().equals(userModel.getPassword())) {
			log.info("authentication successfull.. Generating token..");

			// set the values for the token
			userToken.setUsername(userModel.getUsername());
			userToken.setId(userRepository.findByUsername(userModel.getUsername()).getId());
			userToken.setAuthToken(jwtUtil.generateToken(userdetails));

			return userToken;
		} else {
			log.error("authentication failed");
			throw new UnauthorizedException("Invalid username or password");
		}
	}

	// validates the JWT token
	@Override
	public AuthResponse getValidity(String token) {
		// retrieving the token ( removing the Bearer from the header)
		System.out.println(token);
		String token1 = token.substring(7);
		AuthResponse authResponse = new AuthResponse();
		// if valid
		if (jwtUtil.validateToken(token1)) {
			log.info("Token is valid");

			// extract the user name
			String username = jwtUtil.extractUsername(token1);

			// set the values for the response
			authResponse.setUsername(username);
			authResponse.setValid(true);
			authResponse.setId(userRepository.findByUsername(username).getId());
		} else {
			authResponse.setValid(false);
			log.error("Token is invalid or expired...");
		}

		return authResponse;
	}
}
