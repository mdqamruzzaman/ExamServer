import './App.css';
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './Components/Navbar/Navbar';
import Home from './Components/Home/Home';
import About from './Components/About/About';
import ContactUs from './Components/ContactUs/ContactUs';
import Registration from './Components/Registration/Registration';
import Login from './Components/Login/Login';
import ProtectedRoute from './utils/ProtectedRoute';
import Blog from './Components/Blog/Blog';
import Admin from './Components/Admin/Admin';
import Normal from './Components/Normal/Normal';
import Profile from './Components/Profile/Profile';
import WelcomeAdmin from './Components/Admin/WelcomeAdmin';
import AddQuiz from './Components/AddQuiz/AddQuiz';
import Result from './Components/Result/Result';
import AddCategory from './Components/AddCategory/AddCategory';
import WelcomeNormal from './Components/Normal/WelcomeNormal';
import AdminQuiz from './Components/AddQuiz/AdminQuiz';
import NormalQuiz from './Components/AddQuiz/NormalQuiz';
import AdminCategory from './Components/Category/AdminCategory';
import NormalCategory from './Components/Category/NormalCategory';
import Footer from './Components/Footer/Footer';
import UpdateProfile from './Components/Profile/UpdateProfile';
import UpdateCategory from './Components/Category/UpdateCategory';
import UpdateQuiz from './Components/AddQuiz/UpdateQuiz';
import QuestionsView from './Components/Questions/QuestionsView';
import AddQuestion from './Components/Questions/AddQuestion';
import UpdateQuestion from './Components/Questions/UpdateQuestion';
import NormalQustion from './Components/Questions/NormalQuestion';
import Declaration from './Components/Questions/Declaration';
import { getUser } from "./services/login-service";


function App() {
  return (
    <div>
      <Navbar />
      <main className='App'>

        <Routes>

          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contactus" element={<ContactUs />} />
          <Route path='/registration' element={<Registration />} />
          <Route path='/login' element={<Login />} />
          <Route path='/blogs' element={<Blog />} />


          <Route path='/admin' element={<ProtectedRoute><Admin /></ProtectedRoute>}>
            <Route path='' element={<WelcomeAdmin />} />
            <Route path='profile' element={<Profile />} />
            <Route path='category' element={<AdminCategory />} />
            <Route path='addquiz' element={<AddQuiz />} />
            <Route path='quiz' element={<AdminQuiz />} />
            <Route path='result' element={<Result />} />
            <Route path='addcategory' element={<AddCategory />} />
            <Route path='updatecategory/:id' element={<UpdateCategory />} />
            <Route path='updateQuiz/:id' element={<UpdateQuiz />} />
            <Route path='viewQuestions/:id/:title' element={<QuestionsView />} />
            <Route path='addquestion/:id/:title' element={<AddQuestion />} />
            <Route path='updatequestion/:questionID/:quizID/:title' element={<UpdateQuestion />} />
          </Route>

          <Route path='/normal' element={<ProtectedRoute><Normal /></ProtectedRoute>}>
            <Route path='' element={<WelcomeNormal />} />
            <Route path='profile' element={<Profile />} />
            <Route path='category' element={<NormalCategory />} />
            <Route path='quiz' element={<NormalQuiz />} />
            <Route path='updateprofile/:id' element={<UpdateProfile />} />
            <Route path='declaration/:questID/:maxMarks/:numberofquestion/:title/:description' element={<Declaration />} />
          </Route>



          <Route path='question/:quesID/:title' element={<ProtectedRoute><NormalQustion /></ProtectedRoute>} />
          <Route path='/result/:marksGot/:correctAnswer/:attempted/' element={<ProtectedRoute><Result /></ProtectedRoute>} />

        </Routes>
      </main>
      <Footer />
    </div>

  );
}

export default App;
