import pic from './profile.png';
import { getAllUser } from "../../services/user-service";
import { useState } from "react";
import { useEffect } from "react";
import './WelcomeAdmin.css';

function WelcomeAdmin() {
    const [alluser, setAllUser] = useState([]);
    const getAllActiveUser = () => {
        getAllUser().then((response) => {
            setAllUser(response);
        })
    }
    useEffect(() => {
        getAllActiveUser();
    }, [])

    return (
        <div>
            <section>
                <div className="container" >
                    <h1><b>All Active Users</b></h1>
                    <div className="cards">
                        {
                            alluser?.map((user) => (
                                <div className="col-md-6">
                                    <div className="card">
                                        <img style={{ padding: "10px", maxWidth: "100px", maxHeight: "100px", borderRadius: "50%" }} src={pic} alt='' position="top" />
                                        <p>ID: {user.id}</p>
                                        <p>USERNAME: {user.username}</p>
                                        <p>FIRSTNAME: {user.firstname}</p>
                                        <p>LASTNAME: {user.lastname}</p>
                                        <p>Domain: {user.domain}</p>
                                        <p>EMAIL: {user.email}</p>
                                        <p>ROLE: {user.authorities[0].authority}</p>
                                    </div>
                                </div>

                            ))
                        }

                    </div>
                </div>
            </section>
        </div>
    );
}

export default WelcomeAdmin;