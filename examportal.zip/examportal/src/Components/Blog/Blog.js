import React from "react";

function Blog() {
    return ( <div>
        <h1>Blog is coming soon!!!</h1>
    </div> );
}

export default Blog;