import { MDBCard, MDBCardBody, MDBCardText } from "mdb-react-ui-kit";
import { Link, useParams } from "react-router-dom";


function Result() {
    const { marksGot } = useParams();
    const { correctAnswer } = useParams();
    const { attempted } = useParams();
    // const {numberofQuestions} = useParams();

    // Function will execute on click of button
    const downloadpdf = () => {
        // using Java Script method to get PDF file
        fetch('result.pdf').then(response => {
            response.blob().then(blob => {
                // Creating new object of PDF file
                const fileURL = window.URL.createObjectURL(blob);
                // Setting various property values
                let alink = document.createElement('a');
                alink.href = fileURL;
                alink.download = 'result.pdf';
                alink.click();
            })
        })
    }

    return (<div className="bootstrap-wrapper">
        <div className="container">
            <MDBCard>
                <MDBCardBody>
                    <h1>Result !!!</h1>
                    <MDBCardText>Marks Obtained: <b>{marksGot}</b></MDBCardText>
                    <MDBCardText>Correct Answer: <b>{correctAnswer}</b></MDBCardText>
                    <MDBCardText>Attempted: <b>{attempted}</b></MDBCardText>
                </MDBCardBody>
                <div>

                    <button className='btn btn-primary' style={{ marginBottom: "10px" }} onClick={downloadpdf}>Download</button>
                    <button className='btn btn-success' style={{ marginBottom: "10px", color:"white" }}><Link to={"/normal"}>Home</Link></button>
                </div>
            </MDBCard>

        </div>

    </div>);
}

export default Result;