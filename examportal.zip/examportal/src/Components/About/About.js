import { MDBCard, MDBCardBody, MDBContainer } from "mdb-react-ui-kit";
import React  from 'react';

function About() {
    return (<div>
        <MDBContainer >
            <MDBCard className='text-black m-5' style={{ borderRadius: '25px' }}>
                <MDBCardBody>

                    <p>👋 Welcome to Quiz App!! My name is <b>Md Qamruzzaman</b> I'm a passionate Java Full Stack Engineer with a strong background in building Microservices and web applications. I specialize in leveraging the power of Java and the Spring Boot framework to create robust and scalable solutions.</p>

                    <p>💻 My expertise lies in developing backend services using Java and Spring Boot. I have hands-on experience in designing and implementing Microservices architectures, ensuring high performance and maintainability. I have a deep understanding of RESTful APIs and have successfully integrated them with various frontend frameworks.</p>

                    <p>🌐 On the frontend side, I'm proficient in React.js and JavaScript, enabling me to create dynamic and interactive user interfaces. I believe in delivering seamless user experiences by combining powerful backend functionality with intuitive frontend designs.</p>

                    <p>☁️ Additionally, I have worked extensively with cloud technologies, specifically Amazon Web Services (AWS). I have leveraged AWS services to deploy and scale applications, ensuring reliable performance and cost efficiency.</p>

                    <p>🛢️ In terms of databases, I have hands-on experience with both relational databases such as MySQL and NoSQL databases like MongoDB. I understand the nuances of data modeling and have implemented efficient database solutions to support application requirements.</p>

                    <p>🔨 Throughout my career, I have utilized build tools such as Maven and Gradle to streamline the development process, ensuring efficient dependency management and automated builds.</p>

                    <p>📚 I am an avid learner and stay updated with the latest industry trends and technologies. I actively participate in communities, attend conferences, and engage in continuous learning to enhance my skills and broaden my knowledge.</p>

                    <p>🤝 I'm passionate about collaborating with cross-functional teams, translating business requirements into technical solutions, and delivering high-quality software within project timelines.</p>

                    <p>🌟 If you're looking for a skilled Java Full Stack Engineer who can contribute to the development of cutting-edge applications, please don't hesitate to reach out. I'm always open to new opportunities and exciting projects.</p>

                </MDBCardBody>
            </MDBCard>
        </MDBContainer>
    </div>);
}

export default About;