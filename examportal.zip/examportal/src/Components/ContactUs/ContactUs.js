import { MDBCard, MDBCardBody, MDBCol, MDBContainer, MDBRow, MDBInput, MDBIcon, MDBCardImage } from "mdb-react-ui-kit";
import React  from 'react';
import { myAxios } from "../../services/helper";
import Swal from "sweetalert2";

function ContactUs() {
    const [state, setState]=React.useState({
        name:"",
        email:"",
        message:""
    })
    function handlechange(event){
        const value=event.target.value;
        setState({
            ...state,
            [event.target.name]:value
        });
    }
    const handleContactUs=(event)=>{
        event.preventDefault();
        const data={
            name:state.name,
            email:state.email,
            message:state.message
        }
        myAxios.post("user/contactUs/create", data).then((response)=>{
            Swal.fire('Request Submitted');
        })
    }
    return (<div className="bootstrap-wrapper">
        <div className="container">
            <div className="row">
                <div className="col-md-6- offset-md-3">
                    <form onSubmit={handleContactUs}>
                        <MDBContainer fluid>
                            <MDBCard className='text-black m-5' style={{ borderRadius: '25px' }}>
                                <MDBCardBody>
                                    <MDBRow>
                                        <MDBCol md='10' lg='6' className='order-2 order-lg-1 d-flex flex-column align-items-center'>

                                            <p className="text-center h2 fw-bold mb-5 mx-1 mx-md-4 mt-4">Enquiry Here!!</p>

                                            <div className="d-flex flex-row align-items-center mb-4 ">
                                                <MDBIcon fas icon="user me-3" size='lg' />
                                                <MDBInput placeholder='Name' name='name' value={state.name} type='text' className='w-100' required="true" onChange={handlechange} />
                                            </div>
                                            <div className="d-flex flex-row align-items-center mb-4">
                                                <MDBIcon fas icon="lock me-3" size='lg' />
                                                <MDBInput placeholder='email' name='email' type='email' value={state.email} className='w-100' required="true" onChange={handlechange}/>
                                            </div>
                                            <div className="d-flex flex-row align-items-center mb-4">
                                                <MDBIcon fas icon="lock me-3" size='lg' />
                                                <MDBInput placeholder='message' name='message' type='text' value={state.message} className='w-100' required="true" onChange={handlechange}/>
                                            </div>

                                            <div>
                                                <button className='btn btn-primary' size='md' type="submit" value={"submit"} style={{ margin: '5px' }}> Submit</button>
                                            </div>
                                        </MDBCol>

                                        <MDBCol md='10' lg='6' className='order-1 order-lg-2 d-flex align-items-center'>
                                            <MDBCardImage src='https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/draw1.webp' fluid />
                                        </MDBCol>

                                    </MDBRow>
                                </MDBCardBody>
                            </MDBCard>
                        </MDBContainer>
                    </form>
                </div>
            </div>
        </div>

    </div>);
}

export default ContactUs;