import { MDBCard, MDBCardBody, MDBCol, MDBContainer, MDBRow, MDBInput, MDBIcon, MDBCardImage } from "mdb-react-ui-kit";
import {  MDBCardText } from "mdb-react-ui-kit";
import React from "react";
import { addCategory } from "../../services/CategoryService";
import Swal from "sweetalert2";

function AddCategory() {
    const[state, setState]=React.useState({
        title:'',
        description:''
    })
    function handleChange(event){
        const value=event.target.value;
        setState({
            ...state,
            [event.target.name]:value
        });
    }

    const handleSubmit=(event)=>{
        event.preventDefault();
        const data ={
            title:state.title,
            description:state.description
        }
        addCategory(data).then((response)=>{
            Swal.fire('Category Added','','success');
        })
    }
    return (<div>
        <MDBCard>
            <MDBCardBody>
                <h1>Add New Category</h1>
                <MDBCardText>
                    <div className="bootstrap-wrapper">
                        <div className="row">
                            <div className="">
                                <form onSubmit={handleSubmit}>
                                    <MDBContainer fluid>
                                        <MDBCard className='text-black m-5' style={{ borderRadius: '25px' }}>
                                            <MDBCardBody>
                                                <MDBRow>
                                                    <MDBCol md='10' lg='6'>

                                                        <div className="d-flex flex-row align-items-center mb-4 ">
                                                            <MDBIcon fas icon="file-alt me-3" size='lg' />
                                                            <MDBInput placeholder='Title' name='title' type='text' className='w-100' required="true" onChange={handleChange} />
                                                        </div>
                                                        <div className="d-flex flex-row align-items-center mb-4">
                                                            <MDBIcon fas icon="file-alt me-3" size='lg' />
                                                            <MDBInput placeholder='Description' name='description' type='text' size="50" className='w-100' required="true" onChange={handleChange} />
                                                        </div>

                                                        <div>
                                                            <button className='btn btn-primary' size='md' type="submit" value={"submit"} style={{ margin: '5px' }}>Add New Category</button>
                                                            <button className='btn btn-danger' type="reset" value={"reset"} size='md' >Clear</button>
                                                        </div>
                                                    </MDBCol>

                                                    <MDBCol md='10' lg='6'>
                                                        <MDBCardImage src='https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/draw1.webp' fluid />
                                                    </MDBCol>

                                                </MDBRow>
                                            </MDBCardBody>
                                        </MDBCard>
                                    </MDBContainer>
                                </form>
                            </div>

                        </div>
                    </div>
                </MDBCardText>
            </MDBCardBody>
        </MDBCard>
    </div>);
}

export default AddCategory;