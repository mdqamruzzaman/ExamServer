import { Box, InputLabel, MenuItem, Select, TextField } from "@mui/material";
import { MDBCard, MDBCardBody } from "mdb-react-ui-kit";
import { useState } from "react";
import { Form, FormControl } from "react-bootstrap";
import { useParams } from "react-router-dom";
import { addQuestion } from "../../services/QuestionService";
import Swal from "sweetalert2";

function AddQuestion() {
    const { id } = useParams();
    const { title } = useParams();
    const [question, setQuestions] = useState({
        content: "",
        option1: "",
        option2: "",
        option3: "",
        option4: "",
        answer: ""

    })
    function handleChange(event) {
        const value = event.target.value;
        setQuestions({
            ...question,
            [event.target.name]: value
        });
    }
    const handleSubmit = (event) => {
        event.preventDefault();

        const data = {
            content: question.content,
            option1: question.option1,
            option2: question.option2,
            option3: question.option3,
            option4: question.option4,
            answer: question.answer,
            quiz:{
                qid:id
            }
        }
        // call api from backend
        addQuestion(data).then((response) => {
            Swal.fire("Question Added", "", "success");
        })
    }
    return (<div>
        <h3 style={{ textAlign: "left", marginTop: "10px" }}>Add Question to <span style={{ color: "blue" }}><b>{title}</b></span></h3>
        <MDBCard>
            <MDBCardBody>
                <Box>
                    <Form onSubmit={handleSubmit}>
                        <div className="col-md-7">
                            <TextField fullWidth label="Write Question Content" placeholder="Write Question" type="text" name="content" value={question.content} required="true" onChange={handleChange} />
                        </div>
                        <div className="row" style={{ margin: "10px" }}>
                            <div className="col=md-6" style={{ margin: "10px" }}>
                                <TextField fullWidth label="Option 1" placeholder="Enter Option 1" type="text" name="option1" value={question.option1} required="true" onChange={handleChange} />
                            </div>
                            <div className="col=md-6" style={{ margin: "10px" }}>
                                <TextField fullWidth label="Option 2" placeholder="Enter Option 2" type="text" name="option2" value={question.option2} required="true" onChange={handleChange} />
                            </div>
                        </div>
                        <div className="row" style={{ margin: "10px" }}>
                            <div className="col=md-6" style={{ margin: "10px" }}>
                                <TextField fullWidth label="Option 3" placeholder="Enter Option 3" type="text" name="option3" value={question.option3} required="true" onChange={handleChange} />
                            </div>
                            <div className="col=md-6" style={{ margin: "10px" }}>
                                <TextField fullWidth label="Option 4" placeholder="Enter Option 4" type="text" name="option4" value={question.option4} required="true" onChange={handleChange} />
                            </div>
                        </div>
                        <div style={{ textAlign: "left", marginTop: "10px", marginLeft: "10px", width: "50%" }}>
                            <Box sx={{ minWidth: 200 }}>

                                <label>Select Answer:</label>
                                <select value={question.answer} name="answer" label="Select Answer" onChange={handleChange} style={{ maxWidth: "200px" }}>
                                    <option>{question.option1}</option>
                                    <option>{question.option2}</option>
                                    <option>{question.option3}</option>
                                    <option>{question.option4}</option>
                                </select>

                            </Box>
                        </div>
                        <div>
                            <button className='btn btn-primary' size='md' type='submit' value={'submit'} style={{ margin: '5px' }}>Add Question</button>
                            <button className='btn btn-danger' type="reset" value={"reset"} size='md' >Clear</button>
                        </div>
                    </Form>
                </Box>
            </MDBCardBody>
        </MDBCard>
    </div>);
}

export default AddQuestion;