import { useState } from "react";
import { getQuestionofQuiz } from "../../services/QuizService";
import { useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Swal from "sweetalert2";

function NormalQustion() {
    const navigate = useNavigate();
    const [questions, setQuestions] = useState();
    const { quesID } = useParams();
    const { title } = useParams();
    let marksGot = 0;
    let correctAnswer = 0;
    let attempted = 0;

    function handleChange(event) {
        const value = event.target.value
        questions.forEach((q) => {
            q['givenAnswer'] = value
        })

    }

    // evaluating marks
    function handleSubmit(e) {
        Swal.fire({
            title: 'Do you want Submit Quiz?',
            showCancelButton: true,
            confirmButtonText: 'Submit',
            icon: "info"
        }).then((result) => {

            if (result.isConfirmed) {
                // calculation
                questions.forEach(q => {
                    let singleMarks = questions[0].quiz.maxMarks / questions[0].quiz.numberofQuestions;
                    if (q.givenAnswer === q.answer) {
                        correctAnswer++;
                        marksGot += singleMarks;
                    }
                    if (q.givenAnswer.trim() != '') {
                        attempted++;
                    }
                });
                navigate(`/result/${marksGot}/${correctAnswer}/${attempted}`);
            }
        })
    }
    // API call
    const getQuestionofQuizByID = () => {
        getQuestionofQuiz(quesID).then((response) => {

            // Add one more field in each questions set 
            response.forEach(r => {
                r['givenAnswer'] = '';
            });

            setQuestions(response);
        })
    }
    useEffect(() => {
        getQuestionofQuizByID();
    }, []);

    return (
        <div className="bootstrap-wrapper">
            <div className="container-fluid">
                <div className="row" style={{ marginTop: "10px" }}>
                    <div className="col-md-2">
                        <h3>Instruction</h3>

                    </div>
                    <div className="col-md-8">
                        <h3>On Going Quiz of <b> {title} </b></h3>
                        <div className="cards">
                            {
                                questions?.map((question, i) => (
                                    <div className="card">
                                        <span style={{ textAlign: "left", paddingLeft: "30px" }}><b>Q{i + 1}.</b> {question.content}</span>
                                        <hr />
                                        <div className="row" style={{ margin: "5px" }}>
                                            <div className="col-md-6">
                                                <input type="radio" value={question.option1} name={i} onChange={handleChange} />{question.option1}
                                            </div>
                                            <div className="col-md-6">
                                                <input type="radio" value={question.option2} name={i} onChange={handleChange} />{question.option2}
                                            </div>
                                        </div>
                                        <div className="row" style={{ margin: "5px" }}>
                                            <div className="col-md-6">
                                                <input type="radio" value={question.option3} name={i} onChange={handleChange} />{question.option3}
                                            </div>
                                            <div className="col-md-6">
                                                <input type="radio" value={question.option4} name={i} onChange={handleChange} />{question.option4}
                                            </div>
                                        </div>
                                    </div>
                                ))
                            }
                            <div className="container">
                                <button className='btn btn-primary' style={{ marginBottom: "10px" }} onClick={e => handleSubmit(e)}>Submit</button>
                            </div>

                        </div>

                    </div>
                    <div className="col-md-2">
                        <h3>Progress Bar</h3>
                    </div>

                </div>

            </div>

        </div>
    );
}

export default NormalQustion;