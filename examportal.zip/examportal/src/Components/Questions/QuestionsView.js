import { MDBCard, MDBCardBody, MDBCardText, MDBRow } from "mdb-react-ui-kit";
import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { getQuestionofQuiz } from '../../services/QuizService';
import { deleteQuestion } from "../../services/QuestionService";
import Swal from "sweetalert2";

function QuestionView() {
    const { id } = useParams();
    const { title } = useParams();
    const [questions, setQuestions] = useState([]);
    

    const getAllQuestions = () => {
        getQuestionofQuiz(id).then((response) => {
            setQuestions(response);
        })
    }
    useEffect(() => {
        getAllQuestions();
    }, [])
    const deleteQuestionById = (id,e) =>{
        deleteQuestion(id).then((response)=>{
            Swal.fire("Question Deleted","","success");
        })
    }
console.log(questions)
    return (
        <div className="bootstrap-wrapper">
            <div className="container-fluid">
                <MDBCard>
                    <MDBCardBody>
                        <div>
                            <button style={{background:"lightblue"}}><Link to={`/admin/addquestion/${id}/${title}`}>Add Questions</Link></button>
                            <h3 style={{ textAlign: "left" }}>Questions of <span style={{ color: "blue" }}>{title}</span></h3>
                        </div>
                        <MDBRow>
                            <div className="col-md-12">
                                {
                                    questions?.map((question, i) => (
                                        <MDBCard>
                                            <MDBCardBody>

                                                <MDBCardText>
                                                    <div className="col-md-12" style={{ textAlign: "left", paddingLeft: "30px" }}>
                                                        <b>Q{i + 1}. </b>
                                                        <span>{question.content}</span>
                                                    </div>

                                                    <div className="container-fluid">
                                                        <div className="row">
                                                            <div className="col-md-6">
                                                                <p><b>1)</b> {question.option1}</p>
                                                            </div>
                                                            <div className="col-md-6">
                                                                <p><b>2)</b> {question.option2}</p>
                                                            </div>
                                                        </div>
                                                        <div className="row">

                                                            <div className="col-md-6">
                                                                <p><b>3)</b> {question.option3}</p>
                                                            </div>
                                                            <div className="col-md-6">
                                                                <p><b>4)</b> {question.option4}</p>
                                                            </div>
                                                        </div>
                                                        <div className="row">
                                                            <div className="col-md-6">
                                                                <p style={{color:"green"}}>Hint: {question.answer}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <button style={{background:"lightgreen", margin:"30px"}}><Link to={`/admin/updatequestion/${question.quesID}/${id}/${title}`}>Update Question</Link></button>
                                                        <button style={{background:"indianred", margin:"20px"}} onClick={e => deleteQuestionById(question.quesID,e)}>Delete Question</button>
                                                    </div>
                                                </MDBCardText>
                                            </MDBCardBody>
                                        </MDBCard>
                                    ))
                                }
                            </div>
                        </MDBRow>
                    </MDBCardBody>
                </MDBCard>
            </div>
        </div>
    );
}

export default QuestionView;