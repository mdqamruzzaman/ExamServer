import { MDBCard, MDBCardHeader, MDBCardText, MDBCardTitle } from "mdb-react-ui-kit";
import { useNavigate, useParams } from "react-router-dom";
import Swal from "sweetalert2";

function Declaration() {
    const { questID } = useParams();
    const { maxMarks } = useParams();
    const { numberofquestion } = useParams();
    const { title } = useParams();
    const { description } = useParams();
    const navigate = useNavigate();

    function handleStart() {
        Swal.fire({
            title: 'Do you want Start Quiz?',
            showCancelButton: true,
            confirmButtonText: 'Yes',
            denyButtonText: `Don't save`,
            icon:"info"
        }).then((result) => {

            if (result.isConfirmed) {
                navigate(`/question/${questID}/${title}`)
            } else if (result.isDenied) {
                Swal.fire('Changes are not saved', '', 'info')
            }
        })
    }

    return (
        <MDBCard>
            <MDBCardHeader>
                <MDBCardTitle><b>Read the Instruction Carefully</b></MDBCardTitle>
                <hr />
                <MDBCardText>
                    <p style={{ textAlign: "left", fontSize: "30px" }}>{title}</p>
                    <p style={{ textAlign: "left", fontSize: "15px" }}>{description}</p>
                </MDBCardText>
                <hr />
                <div style={{ textAlign: "left" }}>
                    <p style={{ fontSize: "25px" }}>Important Instructions:</p>
                    <ul>
                        <li>This quiz is only for practice purpose</li>
                        <li>You have to submit quiz with in <b> {numberofquestion * 2} minutes</b></li>
                        <li>You can Attempt the quiz any number of time</li>
                        <li>Ther are <b>{numberofquestion} Questions</b> in this Quiz</li>
                        <li>This Quiz has <b>{maxMarks} Maximum Marks</b></li>
                        <li>Each Question Carries <b>{maxMarks / numberofquestion} Marks.</b> No negative marking for wrong answer</li>
                        <li>All Question is of MCQ Types</li>
                    </ul>
                    <hr />
                    <p style={{ fontSize: "25px" }}>Attempting Quiz</p>
                    <ul>
                        <li>Click <b>Start Quiz</b> button to start the quiz</li>
                        <li>The time will Start the moment you click the start Quiz button</li>
                        <li>You can not resume the quiz, if interrupted due to any reason</li>
                        <li>Scroll down to move to next question</li>
                        <li>Click on Submit Quiz button on completion of the quiz</li>
                        <li>Report of the test is automatically generated in the form of PDF copy</li>
                    </ul>

                </div>
            </MDBCardHeader>
            <div>
                <button className="btn btn-primary" style={{ margin: "5px", background: "lightblue" }} onClick={handleStart}>Start Quiz</button>
            </div>
        </MDBCard>



    );
}

export default Declaration;