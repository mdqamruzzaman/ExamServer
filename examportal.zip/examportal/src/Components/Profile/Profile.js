import { Table, TableCell, TableRow } from "@mui/material";
import { MDBCard, MDBCardBody } from "mdb-react-ui-kit";
import { Image } from "react-bootstrap";
import profile from "../Profile/profile.png";
import '../Profile/Profile.css';
import { getUser } from "../../services/login-service";
import { Link } from "react-router-dom";

function Profile() {
    const user = getUser();

    return (
        <MDBCard>
            <MDBCardBody>
                <h1>Your Profile Details</h1>
                <div className="bootstrap-wrapper">
                    <div className="container">
                        <div className="container text-center">
                            <Image style={{ padding: "20px", maxWidth: "150px", maxHeight: "150px", borderRadius: "50%" }} src={profile} alt="" className="profile-image" />
                        </div>
                        <div className="row">
                            <div className="col-md-10 offset-md-1">
                                <Table className="table" style={{ color: "green", border: "1px solid green" }}>
                                    <TableRow>
                                        <TableCell>Username</TableCell>
                                        <TableCell><b>{user.username}</b></TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>UserID</TableCell>
                                        <TableCell><b>{user.id}</b></TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>First Name</TableCell>
                                        <TableCell><b>{user.firstname}</b></TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>Last Name</TableCell>
                                        <TableCell><b>{user.lastname}</b></TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>Email</TableCell>
                                        <TableCell><b>{user.email}</b></TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>Phone Number</TableCell>
                                        <TableCell><b>{user.phone}</b></TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>Domain</TableCell>
                                        <TableCell><b>{user.domain}</b></TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell>Adress</TableCell>
                                        <TableCell><b>{user.address}</b></TableCell>
                                    </TableRow>
                                </Table>
                            </div>
                        </div>
                    </div>
                </div>
                <Link class="btn btn-primary" to={`/normal/updateprofile/${user.id}`}>Update</Link>
                <button class="btn btn-danger">Share</button>
            </MDBCardBody>
        </MDBCard>
    );
}

export default Profile;