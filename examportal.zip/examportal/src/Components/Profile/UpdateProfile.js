import { useParams } from "react-router-dom";
import React from 'react';
import {
    MDBContainer,
    MDBRow,
    MDBCol,
    MDBCard,
    MDBCardBody,
    MDBCardImage,
    MDBInput,
    MDBIcon
}
    from 'mdb-react-ui-kit';
import { updateUser } from "../../services/user-service";
import Swal from "sweetalert2";

function UpdateProfile() {
    const { id } = useParams();
    const [state, setState] = React.useState({
        username: "",
        password: "",
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        domain: "",
        address: "",
        profile: ""
    })

    function handleChange(event) {
        const value = event.target.value;
        setState({
            ...state,
            [event.target.name]: value
        });

    }
    const handleUpdate = (event) => {
        event.preventDefault();

        // store user into data
        const data = {
            username: state.username,
            password: state.password,
            firstname: state.firstName,
            lastname: state.lastName,
            email: state.email,
            phone: state.phone,
            domain: state.domain,
            address: state.address,
            profile: state.profile
        }

        // call update api from backend
        updateUser(id, data).then((response) => {
            Swal.fire("Profile Updated", '', 'success');
        })
    }

    return (

        <form onSubmit={handleUpdate}>
            <MDBContainer fluid>
                <MDBCard className='text-black m-5' style={{ borderRadius: '25px' }}>
                    <MDBCardBody>
                        <MDBRow>
                            <MDBCol md='10' lg='6' className='order-2 order-lg-1 d-flex flex-column align-items-center'>

                                <p className="text-center h2 fw-bold mb-5 mx-1 mx-md-4 mt-4">Update Profile</p>

                                <div className="d-flex flex-row align-items-center mb-4 ">
                                    <MDBIcon icon="user me-3" size='lg' />
                                    <MDBInput placeholder='User Name' name='username' value={state.username} type='text' className='w-100' required="true" onChange={handleChange} />
                                </div>
                                <div className="d-flex flex-row align-items-center mb-4">
                                    <MDBIcon fas icon="lock me-3" size='lg' />
                                    <MDBInput placeholder='Password' name='password' value={state.password} type='password' className='w-100' required="true" onChange={handleChange} />
                                </div>
                                <div className="d-flex flex-row align-items-center mb-4 ">
                                    <MDBIcon fas icon="user me-3" size='lg' />
                                    <MDBInput placeholder='First Name' name='firstName' value={state.firstName} type='text' className='w-100' required="true" onChange={handleChange} />
                                </div>
                                <div className="d-flex flex-row align-items-center mb-4 ">
                                    <MDBIcon fas icon="user me-3" size='lg' />
                                    <MDBInput placeholder='Last Name' name='lastName' value={state.lastName} type='text' className='w-100' required="true" onChange={handleChange} />
                                </div>

                                <div className="d-flex flex-row align-items-center mb-4">
                                    <MDBIcon fas icon="envelope me-3" size='lg' />
                                    <MDBInput placeholder='Your Email' name='email' value={state.email} type='email' className='w-100' required="true" onChange={handleChange} />
                                </div>
                                <div className="d-flex flex-row align-items-center mb-4">
                                    <MDBIcon fas icon="phone me-3" size='lg' />
                                    <MDBInput placeholder='Your Phone' name='phone' value={state.phone} type='text' className='w-100' required="true" onChange={handleChange} />
                                </div>
                                <div className="d-flex flex-row align-items-center mb-4">
                                    <MDBIcon fas icon="user me-3" size='lg' />
                                    <MDBInput placeholder='Your Domain i.e Full Stack Enginner' name='domain' value={state.domain} type='text' className='w-100' required="true" onChange={handleChange} />
                                </div>
                                <div className="d-flex flex-row align-items-center mb-4">
                                    <MDBIcon fas icon="home me-3" size='lg' />
                                    <MDBInput placeholder='Your Address' name='address' value={state.address} type='text' className='w-100' required="true" onChange={handleChange} />
                                </div>
                                <div className="d-flex flex-row align-items-center mb-4">
                                    <MDBIcon fas icon="image me-3" size='lg' />
                                    <MDBInput placeholder='Your Profile' name='profile' value={state.profile} type='text' className='w-100' required="true" onChange={handleChange} />
                                </div>
                                <div>
                                    <button className='btn btn-primary' size='md' type='submit' value={'submit'} style={{ margin: '5px' }}>Update</button>
                                    <button className='btn btn-danger' type="reset" value={"reset"} size='md' >Clear</button>
                                </div>
                            </MDBCol>

                            <MDBCol md='10' lg='6' className='order-1 order-lg-2 d-flex align-items-center'>
                                <MDBCardImage src='https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/draw1.webp' fluid />
                            </MDBCol>

                        </MDBRow>
                    </MDBCardBody>
                </MDBCard>
            </MDBContainer>
        </form>
    );
}

export default UpdateProfile;