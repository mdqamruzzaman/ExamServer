
function Result() {
    return (<div>
        <h1>Result Display Here!!</h1>
    </div>);
}

export default Result;