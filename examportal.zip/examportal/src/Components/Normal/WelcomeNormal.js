import { useEffect, useState } from "react";
import { getQuiz } from "../../services/QuizService";
import { MDBCardSubTitle, MDBCardText } from "mdb-react-ui-kit";
import './WelcomeNormal.css';
import { Link } from "react-router-dom";

function WelcomeNormal() {

    const [quizes, setQuizes] = useState([]);

    const getAllQuiz = () => {
        getQuiz().then((response) => {
            setQuizes(response);
        })
    }
    useEffect(() => {
        getAllQuiz();
    }, [])

    return (
        <div>
            <section>
                <div className="container">
                    <h1><b>All Quiz List Here</b></h1>
                    <div className="cards">
                        {
                            quizes?.map((quiz) => (
                                <div className="col-md-4">
                                    <div className="card">
                                        <MDBCardSubTitle>
                                            <MDBCardText>
                                                {quiz.title}
                                                {quiz.description}
                                                <button style={{ margin: "5px", background: 'lightskyblue' }}>Question:{quiz.numberofQuestions} </button>
                                                <button style={{ margin: "5px", background: 'lightblue' }}>Marks: {quiz.maxMarks}</button>
                                                <button style={{ margin: "5px", background: 'lightgreen' }}><Link to={`/normal/declaration/${quiz.qid}/${quiz.maxMarks}/${quiz.numberofQuestions}/${quiz.title}/${quiz.description}`}>Start</Link></button>
                                            </MDBCardText>
                                        </MDBCardSubTitle>
                                    </div>
                                </div>
                            ))
                        }
                    </div>

                </div>
            </section>
        </div>
    );
}

export default WelcomeNormal;