import { Button } from "@mui/material";
import { MDBCard, MDBIcon, MDBListGroup } from "mdb-react-ui-kit";
import { Link } from "react-router-dom";

function Sidebar() {
    return (
        <MDBCard>
            <MDBListGroup>

                <Link to={'/normal'}><Button ><MDBIcon fas icon="home"></MDBIcon>Home</Button></Link>
                <Link to={'/normal/profile'}> <Button><MDBIcon fas icon="user"></MDBIcon>Profile</Button></Link>
                <Link to={'/normal/category'}><Button><MDBIcon fas icon="list-alt"></MDBIcon>Category</Button></Link>
                <Link to={'/normal/quiz'}> <Button><MDBIcon fas icon="question-circle"></MDBIcon>Quiz</Button></Link>
                <Link to={'/normal/result'}><Button><MDBIcon fas icon="poll"></MDBIcon>Result</Button></Link>
                <Link to={'/'}><Button><MDBIcon fas icon="sign-out-alt"></MDBIcon>Logout</Button></Link>
            </MDBListGroup>
        </MDBCard>
    );
}

export default Sidebar;