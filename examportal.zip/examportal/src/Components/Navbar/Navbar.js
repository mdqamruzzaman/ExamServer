import React from 'react';
import {
  Nav,
  NavLink,
  Bars,
  NavMenu,
  NavBtn,
  NavBtnLink,
} from './NavbarElements';
import { useNavigate } from 'react-router-dom';
import { logout } from '../../services/login-service';

const Navbar = () => {
  const navigate = useNavigate();
  const isUserLoggedIn = localStorage.getItem('token');
  return (
    <>
      <Nav> 
        <Bars />
        <NavMenu>
          <NavLink to='/' activeStyle>
            Home
          </NavLink>
          <NavLink to='/about' activeStyle>
            AboutUs
          </NavLink>
          <NavLink to='/contactus' activeStyle>
            ContactUs
          </NavLink>
          <NavLink to='/blogs' activeStyle>
            Blogs
          </NavLink>
          <NavLink to='/registration' activeStyle>
            Registration
          </NavLink>

        </NavMenu>
        <NavBtn>

          {isUserLoggedIn && (

            <NavLink to="/" onClick={() => { navigate("/"); }}
            >
              {" "}
              <NavBtnLink className="btn btn-success logout-button" onClick={logout}
              >
                Logout
              </NavBtnLink>
            </NavLink>

          )
          }
        </NavBtn>
      </Nav>
    </>
  );
};

export default Navbar;