import React from 'react';
import { useEffect } from "react";
import Swal from 'sweetalert2';
import Select from '@mui/material/Select';
import Box from '@mui/material/Box';
import FormControl from '@mui/material/FormControl';
import { getCategories } from "../../services/CategoryService";
import {
    MDBContainer,
    MDBRow,
    MDBCol,
    MDBCard,
    MDBCardBody,
    MDBCardImage,
    MDBInput,
    MDBIcon
}
    from 'mdb-react-ui-kit';
import { InputLabel, MenuItem, Switch } from '@mui/material';
import { useParams } from 'react-router-dom';
import { UpdateQuizById } from '../../services/QuizService';

function UpdateQuiz() {
    const [category, setCategory] = React.useState([]);
    const { id } = useParams();
    const [cid, setcid] = React.useState();
    const [state, setState] = React.useState({
        title: "",
        description: "",
        maxMarks: "",
        numberofQuestions: "",

    })
    const [publish, setPublish] = React.useState({
        checked: false,
    })

    // handle Publish Status
    function handlePublish(event) {
        const value = event.target.value;
        setPublish({
            ...publish,
            [event.target.name]: value
        });
    }

    function handleChange(event) {
        const value = event.target.value;
        setState({
            ...state,
            [event.target.name]: value
        });
    }

    // Update Quiz
    const handleSubmit = (event) => {
        event.preventDefault();
        const data = {
            title: state.title,
            description: state.description,
            maxMarks: state.maxMarks,
            numberofQuestions: state.numberofQuestions,
            category: {
                cid: cid
            }
        }
        // call API
        UpdateQuizById(id, data).then((response) => {
            Swal.fire("Quiz Updated", '', 'success');
        })
    }

    // Get All Category
    const getAllCategories = () => {
        getCategories().then((response) => {
            setCategory(response);
        });
    }
    useEffect(() => {
        getAllCategories();
    }, [])

    const handleCategory = (event) => {
        setcid(event.target.value);
    };

    return (
        <div className="row">

            <form onSubmit={handleSubmit}>
                <MDBContainer fluid>
                    <MDBCard className='text-black m-5' style={{ borderRadius: '25px' }}>
                        <MDBCardBody>
                            <MDBRow>
                                <MDBCol md='10' lg='6' className='order-2 order-lg-1 d-flex flex-column align-items-center'>

                                    <p className="text-center h2 fw-bold mb-5 mx-1 mx-md-4 mt-4">Update Quiz</p>

                                    <div className="d-flex flex-row align-items-center mb-4 ">
                                        <MDBIcon icon="user me-3" size='lg' />
                                        <MDBInput placeholder='Title' name='title' value={state.title} type='text' className='w-100' required="true" onChange={handleChange} />
                                    </div>
                                    <div className="d-flex flex-row align-items-center mb-4">
                                        <MDBIcon fas icon="lock me-3" size='lg' />
                                        <MDBInput placeholder='Description' name='description' value={state.description} type='text' className='w-100' required="true" onChange={handleChange} />
                                    </div>
                                    <div className="d-flex flex-row align-items-center mb-4 ">
                                        <MDBIcon fas icon="user me-3" size='lg' />
                                        <MDBInput placeholder='Maximum Marks' name='maxMarks' value={state.maxMarks} type='text' className='w-100' required="true" onChange={handleChange} />
                                    </div>
                                    <div className="d-flex flex-row align-items-center mb-4 ">
                                        <MDBIcon fas icon="user me-3" size='lg' />
                                        <MDBInput placeholder='Questions' name='numberofQuestions' value={state.numberofQuestions} type='text' className='w-100' required="true" onChange={handleChange} />
                                    </div>
                                    <div className="d-flex flex-row align-items-center mb-4 ">
                                        <MDBIcon fas icon="list-alt me-3" size='lg' />
                                        <Box sx={{ minWidth: 210 }}>
                                            <FormControl fullWidth>
                                            <InputLabel>Category</InputLabel>
                                                <Select
                                                    label="Category"
                                                    onChange={handleCategory}>
                                                    {
                                                        category.map((data) => (
                                                            <MenuItem value={data.cid}>{data.title}</MenuItem>
                                                        ))
                                                    }
                                                </Select>
                                            </FormControl>
                                        </Box>
                                    </div>
                                    <div className="d-flex flex-row align-items-center mb-4 ">
                                        <label>
                                            <span>Publish Status</span>
                                            <Switch onChange={handlePublish} name='checked' value={publish.checked} required="true" />
                                        </label>
                                    </div>
                                    <div>
                                        <button className='btn btn-primary' size='md' type='submit' value={'submit'} style={{ margin: '5px' }}>Update Quiz</button>
                                        <button className='btn btn-danger' type="reset" value={"reset"} size='md' >Clear</button>
                                    </div>
                                </MDBCol>

                                <MDBCol md='10' lg='6' className='order-1 order-lg-2 d-flex align-items-center'>
                                    <MDBCardImage src='https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/draw1.webp' fluid />
                                </MDBCol>

                            </MDBRow>
                        </MDBCardBody>
                    </MDBCard>
                </MDBContainer>
            </form>

        </div >


    );
}

export default UpdateQuiz;