import { MDBCard, MDBCardBody, MDBCardSubTitle, MDBCardText } from "mdb-react-ui-kit";
import { useEffect, useState } from "react";
import { getQuiz } from "../../services/QuizService";

function NormalQuiz() {
    const [quiz, setQuiz] = useState([]);
    const getAllQuiz = () => {
        getQuiz().then((response) => {
            setQuiz(response);
        });
    }
    useEffect(() => {
        getAllQuiz();
    }, [])
    return (<div>
        <MDBCard>
            <MDBCardBody>
                {
                    quiz?.map((data) => (
                        <MDBCardSubTitle>
                            <MDBCardText style={{ textAlign: 'left', border: '1px solid green', margin: '10px' }}>
                                <h3 style={{ color: "black" }}>{data.title}</h3>
                                <h6 style={{ color: "green" }}>{data.description}</h6>
                                <button style={{ margin: '10px', background: 'lightblue' }}>  Max Marks: {data.maxMarks}</button>
                                <button style={{ margin: '10px', background: 'lightskyblue' }}> Questions: {data.numberofQuestions}</button>
                                <button style={{ margin: '10px', background: "lightgreen" }}>Start</button>
                            </MDBCardText>
                        </MDBCardSubTitle>
                    ))
                }
                <div className="container text-center mt20">
                    <button className="btn btn-primary" >List All Quiz</button>
                </div>
            </MDBCardBody>
        </MDBCard>
    </div>);
}

export default NormalQuiz;