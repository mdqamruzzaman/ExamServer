import { MDBCard, MDBCardBody, MDBCardSubTitle, MDBCardText } from "mdb-react-ui-kit";
import { useEffect, useState } from "react";
import { deleteQuiz, getQuiz } from "../../services/QuizService";
import Swal from "sweetalert2";
import { Link } from "react-router-dom";

function AdminQuiz() {
    const [quiz, setQuiz] = useState([]);

    // Get All Quiz
    const getAllQuiz = () => {
        getQuiz().then((response) => {
            setQuiz(response);
        });
    }
    useEffect(() => {
        getAllQuiz();
    }, [])

    // Delete Quiz
    const hankdledelete = (id, e) => {
        deleteQuiz(id).then((response) => {
            Swal.fire(response, '', "success");
        }).catch((error) => {
            Swal.fire(error, '', 'error');
        })
    }

    return (<div>
        <MDBCard>
            <MDBCardBody>
                {
                    quiz?.map((data) => (
                        <MDBCardSubTitle>
                            <MDBCardText style={{ textAlign: 'left', border: '1px solid green', margin: '10px' }}>

                                <h3 style={{ color: "black" }}>{data.title}</h3>
                                <h6 style={{ color: "green" }}>{data.description}</h6>
                                <button style={{ margin: '10px', background: 'lightgreen' }}><Link to={`/admin/viewQuestions/${data.qid}/${data.title}`}>Questions</Link></button>
                                <button style={{ margin: '10px', background: 'lightblue' }}>  Max Marks: {data.maxMarks}</button>
                                <button style={{ margin: '10px', background: 'lightskyblue' }}> Questions: {data.numberofQuestions}</button>
                                <button style={{ margin: '10px', background: "aqua" }}><Link to={`/admin/updateQuiz/${data.qid}`}>Update</Link></button>
                                <button style={{ margin: '10px', background: "lightgreen" }}>Start</button>
                                <button style={{ margin: '10px', background: "indianred" }} onClick={e => hankdledelete(data.qid, e)}>Delete</button>
                            </MDBCardText>
                        </MDBCardSubTitle>
                    ))
                }
                <div className="container text-center mt20">
                    <Link className="btn btn-primary" to={"/admin/addquiz"}>Add New Quiz</Link>
                </div>
            </MDBCardBody>
        </MDBCard>
    </div>);
}

export default AdminQuiz;