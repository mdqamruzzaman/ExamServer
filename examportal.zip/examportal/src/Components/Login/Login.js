import { MDBCard, MDBCardBody, MDBCol, MDBContainer, MDBRow, MDBInput, MDBIcon, MDBCardImage } from "mdb-react-ui-kit";
import React from 'react';
import { getCurrentUser, getUserRole, login, logout, setUser } from "../../services/login-service";
import Swal from "sweetalert2";
import { loginUser } from "../../services/login-service";
import { useNavigate } from "react-router-dom";


function Login() {
    const navigate = useNavigate();
    const [state, setState] = React.useState({
        username: '',
        password: ''
    })

    function handleChange(event) {
        const value = event.target.value;
        setState({
            ...state,
            [event.target.name]: value
        });
    }
    const handleSubmit = (event) => {
        event.preventDefault();
        // validate the user
        if (state.username === '' || state.username === null) {
            alert('Username is required');
        }
        const data = {
            username: state.username,
            password: state.password
        }
        // console.log(data);
        login(data).then((resp) => {
           
            // Swal.fire('Token Generated', '', 'success');

            // generate token here!!
            loginUser(resp.authToken);

            // get Current User
            getCurrentUser().then((resp) => {
                setUser(resp);
                
                if (getUserRole() === 'ADMIN' || getUserRole() === 'admin') {
                    // admin dashboard
                    navigate("/admin");
                } else if (getUserRole() === 'NORMAL' || getUserRole() === 'normal') {
                    // normal dashboard
                    navigate("/normal");
                } else {
                    logout();
                }

            })

        }).catch((error) => {
            // console.log(error);
            Swal.fire('' + error, '', 'error');
        })
    };
    return (<div className="bootstrap-wrapper">
        <div className="container">
            <div className="row">
                <div className="col-md-6- offset-md-3">
                    <form onSubmit={handleSubmit}>
                        <MDBContainer fluid>
                            <MDBCard className='text-black m-5' style={{ borderRadius: '25px' }}>
                                <MDBCardBody>
                                    <MDBRow>
                                        <MDBCol md='10' lg='6' className='order-2 order-lg-1 d-flex flex-column align-items-center'>

                                            <p className="text-center h2 fw-bold mb-5 mx-1 mx-md-4 mt-4">Login Here!!</p>

                                            <div className="d-flex flex-row align-items-center mb-4 ">
                                                <MDBIcon fas icon="user me-3" size='lg' />
                                                <MDBInput placeholder='User Name' name='username' type='text' className='w-100' required="true" onChange={handleChange} />
                                            </div>
                                            <div className="d-flex flex-row align-items-center mb-4">
                                                <MDBIcon fas icon="lock me-3" size='lg' />
                                                <MDBInput placeholder='Password' name='password' type='password' className='w-100' required="true" onChange={handleChange} />
                                            </div>

                                            <div>
                                                <button className='btn btn-primary' size='md' type="submit" value={"submit"} style={{ margin: '5px' }}>Login</button>
                                                <button className='btn btn-danger' type="reset" value={"reset"} size='md' >Clear</button>
                                            </div>
                                        </MDBCol>

                                        <MDBCol md='10' lg='6' className='order-1 order-lg-2 d-flex align-items-center'>
                                            <MDBCardImage src='https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/draw1.webp' fluid />
                                        </MDBCol>

                                    </MDBRow>
                                </MDBCardBody>
                            </MDBCard>
                        </MDBContainer>
                    </form>
                </div>
            </div>
        </div>

    </div>);
}

export default Login;