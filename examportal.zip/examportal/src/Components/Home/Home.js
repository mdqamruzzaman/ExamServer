import { MDBCard, MDBCardBody, MDBContainer } from "mdb-react-ui-kit";
import Login from "../Login/Login";
import React from 'react';
function Home() {
    return (<div className='container'>
        <MDBContainer >
            <MDBCard className='text-black m-5' style={{ borderRadius: '25px' }}>
                <MDBCardBody>
                    <h2>Welcome to Quiz App!!</h2>
                    <p>You need to first Register Yourself</p>
                    <Login />
                </MDBCardBody>
            </MDBCard>
        </MDBContainer>

    </div>);
}

export default Home;