import { MDBCard, MDBCardBody, MDBCardHeader, MDBCardSubTitle, MDBCardText, MDBCardTitle } from "mdb-react-ui-kit";
import { getCategories } from "../../services/CategoryService";
import { useEffect, useState } from "react";
import Swal from "sweetalert2";
import { deleteCategory } from "../../services/CategoryService";
import { Link } from "react-router-dom";

function AdminCategory() {
    const [category, setCategory] = useState([]);

    // Get all Category
    const getAllCategories = () => {
        getCategories().then((response) => {
            setCategory(response);
        });
    }
    useEffect(() => {
        getAllCategories();
    }, [])

    // Delete Category
    const deleteCategories = (id, e) => {

        deleteCategory(id).then((response) => {
            Swal.fire(response, '', "success")
        }).catch((error) => {
            Swal.fire('Error', '', 'error')
        })
    }


    return (

        <MDBCard>
            <MDBCardBody>
                <MDBCardHeader><h1>All Category List</h1></MDBCardHeader>
                <MDBCardTitle>
                    {
                        category?.map((data) => (
                            <MDBCardSubTitle>
                                <MDBCardText style={{ textAlign: 'left', border: '1px solid green' }}>
                                    <h3 style={{ color: "black" }}>{data.title}</h3>
                                    <h6 style={{ color: "green" }}>{data.description}</h6>
                                    <button style={{ margin: '10px', background: "lightblue" }} ><Link to={`/admin/updatecategory/${data.cid}`}>Update</Link></button>
                                    <button style={{ margin: '10px', background: "indianred" }} onClick={e => deleteCategories(data.cid, e)}>Delete</button>
                                </MDBCardText>
                            </MDBCardSubTitle>
                        ))
                    }
                </MDBCardTitle>
                <div className="container text-center mt20">
                    <Link className="btn btn-primary" to={"/admin/addcategory"}>Add New Category</Link>
                </div>
            </MDBCardBody>
        </MDBCard>);
}
export default AdminCategory;