import { MDBCard, MDBCardBody, MDBCardHeader, MDBCardSubTitle, MDBCardText, MDBCardTitle } from "mdb-react-ui-kit";
import { getCategories } from "../../services/CategoryService";
import { useEffect, useState } from "react";

function NormalCategory() {
    const [category, setCategory] = useState([]);

    const getAllCategories = () => {
        getCategories().then((response) => {
            setCategory(response);
        });
    }
    useEffect(() => {
        getAllCategories();
    }, [])

    return (
        <MDBCard>
            <MDBCardBody>
                <MDBCardHeader><h1>All Category List</h1></MDBCardHeader>
                <MDBCardTitle>

                    {
                        category?.map((data) => (

                            <MDBCardSubTitle>
                                <MDBCardText style={{ textAlign: 'left', border: '1px solid green' }}>
                                    <h3 style={{ color: "black" }}>{data.title}</h3>
                                    <h6 style={{ color: "green" }}>{data.description}</h6>
                                </MDBCardText>
                            </MDBCardSubTitle>

                        ))
                    }
                </MDBCardTitle>
                <div className="container text-center mt20">
                    <button className="btn btn-primary" onClick={getAllCategories}>List All Category</button>
                </div>
            </MDBCardBody>
        </MDBCard>);
}
export default NormalCategory;