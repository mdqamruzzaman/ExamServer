import { Button } from "@mui/material";
import { MDBCard, MDBCardBody, MDBIcon } from "mdb-react-ui-kit";
import { Link } from "react-router-dom";

function Sidebar() {
    return (
        <MDBCard>
            <MDBCardBody>
                
                    <Link to={'/admin'}><Button ><MDBIcon fas icon="home"></MDBIcon>Home</Button></Link>
                    <Link to={'/admin/profile'}> <Button><MDBIcon fas icon="user"></MDBIcon>Profile</Button></Link>
                    <Link to={'/admin/category'}><Button><MDBIcon fas icon="list-alt"></MDBIcon>Category</Button></Link>
                    <Link to={'/admin/quiz'}> <Button><MDBIcon fas icon="question-circle"></MDBIcon>Quiz</Button></Link>
                    <Link to={'/admin/addcategory'}><Button><MDBIcon fas icon="plus"></MDBIcon>Add Category</Button></Link>
                    <Link to={'/admin/addquiz'} ><Button><MDBIcon fas icon="plus"></MDBIcon>Add Quiz</Button></Link>
                    <Link to={'/'}> <Button><MDBIcon fas icon="sign-out-alt"></MDBIcon>Logout</Button></Link>
                
            </MDBCardBody>
        </MDBCard>
    );
}

export default Sidebar;