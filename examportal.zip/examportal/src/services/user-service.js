import { myAxios } from "./helper";
import { getToken } from "./login-service";

// Get Token
const token = getToken();

// Registration of new user
export const registration = (user) => {
    return myAxios.post("user/create", user).then((response) => response.data);
}

// update of user
export const updateUser = (id, data) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.put(`/user/update/${id}`, data, config).then((response) => response.data);
}

// Get User By ID
export const getUserById = (id) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.get(`/user/getuserbyid/${id}`, config).then((response) => response.data);
}

export const getAllUser = () => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.get('/user/getAll', config).then((response) => response.data);
}