import { myAxios } from "./helper"
import { getToken } from "./login-service";

// Get Token
const token = getToken();

// Load all the categories
export const getCategories = () => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.get("/category/getAllCategories", config).then((response) => response.data);
}

// Add Category
export const addCategory = (response) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.post("/category/create", response, config).then((response) => response.data);
}
// Qelete Category
export const deleteCategory = (id) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.delete(`/category/deleteCategory/${id}`, config).then((response) => response.data);
}

// Update Category
export const updateCategory = (id, data) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.put(`/category/updateCategory/${id}`,data, config).then((response) => response.data);
}