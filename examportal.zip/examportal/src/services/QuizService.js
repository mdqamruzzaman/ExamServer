import { myAxios } from "./helper";
import { getToken } from "./login-service";

// Get Token
const token = getToken();

// Add Quiz
export const addquiz = (data) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.post("/quiz/create", data, config).then((response) => response.data);
}

// Get Quiz
export const getQuiz = () => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.get("quiz/getAllCategories", config).then((response) => response.data);
}

// Delete Quiz
export const deleteQuiz = (id) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.delete(`/quiz/quizDelete/${id}`, config).then((response) => response.data);
}

// Update Quiz
export const UpdateQuizById = (id, data) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.put(`/quiz/updateCategory/${id}`, data, config).then((response) => response.data);
}

// Get Question of QuizbyID
export const getQuestionofQuiz = (id) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.get(`/question/getQuestionofquiz/${id}`, config).then((response) => response.data);
}