import { myAxios } from "./helper";
import { getToken } from "./login-service";


// Get Token
const token = getToken();

// Add Question
export const addQuestion = ( data) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.post(`/question/create`, data, config).then((response) => response.data);
}

// Delete Question
export const deleteQuestion = (id) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.delete(`question/deleteQuestion/${id}`, config).then((response)=>response.data);
}

// Update Question
export const updatequestion = (id, data) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.put(`question/updateQuestion/${id}`, data, config).then((response)=> response.data);
}