import { myAxios } from "./helper";

// call login api
export const login = (user) => {
    return myAxios.post("user/login", user).then((response) => response.data);
}

// Get Current User which is loggedIn
export const getCurrentUser = () => {
    const token = getToken();
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.get("user/current_user", config).then((response) => response.data);
}

// set token into localstorage
export const loginUser = (token) => {
    localStorage.setItem('token', token);
    return true;
}

// to check user is logged in or not
export const isLoggedIn = () => {
    let tokenStr = localStorage.getItem('token');
    if (tokenStr === undefined || tokenStr === '' || tokenStr === null) {
        return false;
    } else {
        return true;
    }
}

// logout : remove token from local storage
export const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    return true;
}

// get Token
export const getToken = () => {
    return localStorage.getItem('token');
}

// set userDetails
export const setUser = (user) => {
    return localStorage.setItem('user', JSON.stringify(user));
}

// get userDetails
export const getUser = () => {
    let userStr = localStorage.getItem('user');
    if (userStr != null) {
        return JSON.parse(userStr);
    } else {
        logout();
        return null;
    }
}

// Get User Role Athurity
export const getUserRole = () => {
    let user = getUser();
    return user.authorities[0].authority;
}